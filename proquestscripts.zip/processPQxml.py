# -*- coding: utf-8 -*-
"""
Created on 9/27/2018

@author: Vilja

This is a first pass in processing the ProQuest XML files. Its analogue in 
the older HTML-processing versions is getwitnesses.py.

The next script to run is fixabbreviations-newxml.py
"""

from bs4 import BeautifulSoup
from collections import Counter
import os, re, sys,codecs


rootdir = "/Users/vilja/work/research/digital/"
#mydir = rootdir + "LexisNexis/metatest/"
mydir = rootdir + "ProQuestHearings/NewXML/splitfiles/"
#mydir = rootdir + "ProQuestHearings/NewXML/splittest/"


witnessfilename = rootdir + "ProQuestHearings/witnesslist-newxml-subjfixed.tsv"
#remove the file if it exists because we will append to it below
if os.path.exists(witnessfilename): os.remove(witnessfilename)

#sucountsfn = rootdir + "ProQuestHearings/sucounts-test.csv"

#this is the first line, we write it there right away and append below in the loop.
witnessline = ['HID','title','date','year','congress','session','branch',#
               'committee','subcommittee','lname','fname','hon','suffix',#
               'pos','org','city','state','addl','subjects']

witnesslinetext = '\t'.join(witnessline) + "\n"

with codecs.open(witnessfilename,'a',encoding='utf8') as f:
    f.write(witnesslinetext)
                    
                    
#allsubjects = []

commlist = [] #for debugging
scommlist = []#for debugging
branchlist = []#for debugging
titlelist = []
origtitlelist = []
debugsubj = []
debugwit = []

fn = 0
for item in os.listdir(mydir):
    
    fn +=1
    print "Processing file number {0},{1}".format(fn,item)
    if os.path.isfile(mydir+item) :
        with open(mydir+item) as f0:
            newfile = f0.read()
        soup = BeautifulSoup(newfile,"lxml")
        hearingid = ""
        committee = ""
        subcommittee = ""
        branch = ""
        title = ""
        date = ""
        year = ""
        congress = ""
        session = ""
        subjects = []
        hearingid = soup.find('accession-no').contents[0]
        committeesearch = soup.find_all('gis:committee-source')
        if committeesearch:
            committees = [c.contents for c in committeesearch]
        else:
            agencysearch = soup.find_all('gis:agency-source')
            if agencysearch:
                committees = [c.contents for c in agencysearch]
   
        if len(committees) > 1:
            subcommittee = committees[0][0]
            committee = committees[1][0]
        else:
            subcommittee = ""
            committee = committees[0][0]
        if 'House' in committee: 
            branch = 'House'
            committee = re.sub('\.\s*House.*','',committee)
        elif 'Senate' in committee:          
            branch = 'Senate'
            committee = re.sub('\.\s*Senate.*','',committee)
        elif 'Joint' in committee:
            branch = 'Joint'
            committee = re.sub('\.\s*Joint.*','',committee)
        titlesearch = soup.find('title')
        if titlesearch: 
            title = titlesearch.contents[0]
            cleantitle = re.sub('Congressional Hearing.*','',title)
            cleantitle = re.sub('[.:, ]+$','',cleantitle)
            title = cleantitle
        datesearch = soup.find('date')
        if datesearch: 
            date = datesearch.contents[0]
            year = date[:4]
        subjsearch = soup.find_all('gis:subject')#CHANGE TO GIS SUBJECT!
        if subjsearch:
            for s in subjsearch:
                subjects.append('Subject: ' + s.contents[0].strip())
        congsearch = soup.find('gis:congress')
        if congsearch: congress = congsearch.contents[0]
        sessearch = soup.find('gis:congress-session')
        if sessearch: session = sessearch.contents[0]
        witnessearch = soup.find_all('hearing-participant',{'type':'WITNESS'})
        if witnessearch:
            for w in witnessearch:
                lname = ""
                fname = ""
                hon = ""
                suffix = ""
                pos = ""
                org = ""
                city = ""
                state = ""
                addl = ""
                lnamesearch = w.find('last-name')
                if lnamesearch: lname = lnamesearch.get_text()
                fnamesearch = w.find('first-name')
                if fnamesearch: 
                    fname = fnamesearch.get_text()
                honsearch =  w.find('honorific')
                if honsearch: hon = honsearch.get_text()
                suffsearch = w.find('suffix')
                if suffsearch: suffix = suffsearch.get_text()
                possearch = w.find('personal-role')
                if possearch: pos = possearch.get_text()
                affilsearch = w.find('personal-affiliation')
                if affilsearch: 
                    org = affilsearch.get_text()
                    if org == None: org = affilsearch.find('organization-term').get_text()
                textsearch = w.find('text')
                if textsearch:                        
                    if ',' in textsearch.get_text():
                        els = textsearch.get_text().split(',')
                        if not pos: 
                            pos = els[0]
                            addl = ', '.join([el.strip() for el in els[1:]])
                        else:
                            addl = ', '.join([el.strip() for el in els])
                if not pos and not org:
                    repsearch = w.find('congressperson')
                    if repsearch:
                        possearch = repsearch.find('position')
                        if possearch: pos = possearch.get_text()
                        orgsearch = repsearch.find('rc:party')
                        if orgsearch: org = orgsearch.get_text()
                        statesearch = repsearch.find('rc:state')
                        if statesearch: state = statesearch['code']

                witness = [lname, fname,hon,suffix,pos,org,city,state,addl]
                debugwit.append(witness)
                #this is deliberately built under the witness loop
                #because we want one line per witness
                #not one line per hearing
                witnessline = [hearingid,title,date,year,congress,session,#
                               branch,committee,subcommittee] + witness + subjects
                witnesslinetext = '\t'.join(witnessline) + "\n"
                
                with codecs.open(witnessfilename,'a',encoding='utf8') as f:
                    f.write(witnesslinetext)





#debugging
#debugtitle = [list(a) for a in zip(titlelist,origtitlelist)]
#debugtitletxt = '\n'.join(['\t'.join(l) for l in debugtitle])
#with codecs.open('test.tsv','w',encoding='utf8') as f:
#    f.write(debugtitletxt)

