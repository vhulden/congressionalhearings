# -*- coding: utf-8 -*-
"""
Created on Mon Nov 23 09:39:41 2015

@author: vilja

The basic function of this script is to attempt to get the order of the fields
right; the statefile and place file etc. simply help with that. The next
script (processwitnesslist-cleanup.py) then tries to split up these fields when they
contain additional or incorrect informatin, and fixes states. After that comes the script
that attempts to identify witness affiliations.
"""
import re

workdir = "/Users/vilja/work/research/digital/"
csvfile = "ProQuestHearings/witnesslisttest_abbrfixed.tsv"
#csvfile = "LexisNexis-AHA/testlist.csv"
jobfile = "listsforprocessing/jobtitles-unique.txt"
statefile = "listsforprocessing/states.csv"
placefile = "listsforprocessing/placenames-processed.csv"
writefile = "ProQuestHearings/witnesslisttest_processed.tsv"
#writefile = "LexisNexis-AHA/testlist-processed.csv"


print "Opening files..."

with open(workdir+csvfile) as f:
    witnessfile = f.read()
    filelines = [line for line in witnessfile.split('\n') if line.strip() != '']
    witnesslist = [fline.split('\t') for fline in filelines]
longest = len(max(witnesslist,key=len))


with open(workdir+statefile) as f:
    statenamelist = f.read().splitlines()
    statenamevariants = [line.split(',') for line in statenamelist]
    allpossiblestates = set([item.replace('.','').strip().lower() for sublist in statenamevariants for item in sublist])

with open(workdir+placefile) as f:
    places = set([line.lower() for line in f.read().splitlines()])
    
with open(workdir+jobfile) as f:
    joblist = set([line.lower() for line in f.read().splitlines()])
    
#list of what's going to go into the new witnesslist as defined by maneuvers
#below; give empty values so there's no problem if not all are defined for all witnesses





newwitnesslist = []
howmany = len(witnesslist)

for idx, witnessline in enumerate(witnesslist):
    #reset every time and ensure they're at least defined
    subjectlist = []
    hid = ""
    hdate = ""
    htitle = ""
    hcongress = ""
    hcongressession  = ""
    hcommittee = ""
    wlname = ""
    wfname = ""
    wpos = ""
    worg = ""
    city = ""
    state = ""
    moreinfo = "" #this is bc want to regularize e.g. only one wpos, but don't want to lose info
    print "Processing line {0} of {1}...".format(idx,howmany)
    # pad shorter listlines so as to not have "list index out of range" problems below
    if len(witnessline) < longest:
        witnessline += [''] * (longest - len(witnessline))
    hid = witnessline[0].strip()
    htitle = witnessline[1].strip()
    hdate = witnessline[2].strip()
    hcongressm = re.match('^([0-9]+)-([0-9]+)',witnessline[3].strip())
    if hcongressm:
        hcongress = hcongressm.group(1)
        hcongressession  = hcongressm.group(2)
    hcommittee = witnessline[4].strip()
    wlname = witnessline[5].strip()
    wfname = witnessline[6].strip()
    #the above ones are generally there without fail.
    #now try to fix the ones that get messed up
    #first, check if committee is missing and last name (always in caps) is in its place.
#    lnameorcomm = re.search('[A-Z]+$',witnessline[3].strip(),flags=0)
#    if lnameorcomm is not None:
#       wlname = witnessline[3].strip()
#       wfname = witnessline[4].strip()
#       wpos = witnessline[5].strip() # in these variants this is usually true
 #   if committee is present, add that, and move on to last name
#    else:
#        hcommittee = witnessline[3].strip()
#        wlname = witnessline[4].strip()
#        wfname = witnessline[5].strip()

    
    # do witnessline[7] separately because that's more likely to be a position than an organization
    cell = witnessline[7]
    if cell.strip():
        if ',' in cell:
            found = 0
            cellcontent = cell.split(',')
            if re.match('p\.\s*[0-9]+',cellcontent[0].strip(),flags=0) is None:
                for cellpart in cellcontent:
                    scellpt = cellpart.strip().lower() #cell variant for searching to ignore case
                    if scellpt in joblist:
                        wpos = cellpart.strip()
                        found = 1
                    elif scellpt in allpossiblestates:
                        state = cellpart.strip()
                        found = 1
                    elif scellpt in places:
                        city = cellpart.strip()
                        found = 1
                if found == 0: # this is the default, if nothing matches
                    wpos = cellcontent[0].strip()
                    worg = ",".join(cellcontent[1:].strip()) 
        #then basically do the same options if there are no commas in this cell
        elif re.match('\s*p\.\s*[0-9]+',cell,flags=0) is None:
            scell = cell.strip().lower() #cell variant for searching to ignore case
            if scell in joblist:
                wpos = cell.strip()
            elif scell in places:
                city = cell.strip()
            elif scell in allpossiblestates:
                state = cell.strip()
            elif scell.split()[0].strip() == 'representing':
                wpos = cell.split()[0].strip()
                worg = " ".join(cell.split()[1:])
            elif 'subject:' in scell:
                subjectlist.append(cell.strip())
            else:
                wpos = cell.strip()
    
    for cell in witnessline[8:]: #there are lots with the subjects now
        if cell.strip():
            if ',' in cell:
                if 'Subject:' in cell:
                    subjectlist.append(cell.replace(',',''))
                else:
                    cellcontent = cell.split(',')
                    if re.match('p\.\s*[0-9]+',cellcontent[0].strip(),flags=0) is None:
                        for cellpart in cellcontent:
                            scellpt = cellpart.strip().lower()
                            if scellpt in joblist:
                                wpos = cellpart.strip()
                            elif scellpt in allpossiblestates:
                                state = cellpart.strip()
                            elif scellpt in places:
                                city = cellpart.strip()
                        if len(cellcontent) > 2:
                            if not wpos: 
                                wpos = cellcontent[0].strip()
                            if not state or not city:
                                worg = ",".join(cellcontent[1:]).strip()
                        if len(cellcontent) == 2:
                            if cellcontent[0].strip(): #sometimes get [' ','content...']
                                if cellcontent[0].strip().lower() in joblist:
                                    if not wpos:
                                        wpos = cellcontent[0]
                                    worg = cellcontent[1]
                                elif cellcontent[0].strip().lower() in places and cellcontent[1] in allpossiblestates:
                                    city = cellcontent[0]
                                    state = cellcontent[1]
                                else:
                                    cellwords = cellcontent[0].split()
                                    if len(cellwords) > 1:
                                        if cellwords[0].strip().lower() in joblist or cellwords[1].strip().lower() in joblist:
                                            wpos = cellcontent[0].strip()
                                            worg = cellcontent[1].strip()
                                        else:
                                            worg = ",".join(cellcontent).strip() # this is the default, if nothing matches
                                    elif len(cellwords) == 1:
                                        if cellwords[0].strip().lower() in joblist:
                                            wpos = cellcontent[0].strip()
                                            worg = cellcontent[1].strip()
                                        else:
                                            worg = ",".join(cellcontent).strip() # this is the default, if nothing matches
                        else:
                            worg = cellcontent[1].strip()
                      
            #then basically do the same options if there are no commas in this cell
            # don't process empty cells
            elif cell.strip() and re.match('\s*p\.\s*[0-9]+',cell,flags=0) is None:
                
                scell = cell.strip().lower()
                if not 'subject:' in scell and (scell in joblist or scell.split()[-1] in joblist):
                    wpos = cell.strip()
                elif scell in allpossiblestates:
                    state = cell.strip()
                elif scell in places:
                    city = cell.strip()
                elif 'subject:' in scell:
                    subjectlist.append(cell)
                elif not scell.isdigit():
                    worg = cell.strip()
   
    #and then, finally, put everything in a list
    newlist = [hid,hdate,hcongress,hcongressession,htitle,hcommittee,wlname,wfname,wpos,worg,city,state] + subjectlist
    newwitnesslist.append(newlist)
    

stringlist = []
for wlist in newwitnesslist:
    wstring = "\t".join(wlist)
    stringlist.append(wstring)
witnessestext = "\n".join(stringlist)

with open(workdir+writefile, 'w') as f:
    f.write(witnessestext)
        