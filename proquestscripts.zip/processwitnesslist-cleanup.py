# -*- coding: utf-8 -*-
"""
Created on Sun Nov 20 11:27:53 2016

@author: vilja

This script processes further the results of processwitnesslist.py. It attempts to
extract more information by splitting fields, correct incorrectly identified fields;
and normalize states.
"""
import re

workdir = "/Users/vilja/work/research/digital/"
csvfile = "ProQuestHearings/witnesslisttest_abbrfixed.tsv"
jobfile = "listsforprocessing/jobtitles-unique.txt"
statefile = "listsforprocessing/states.csv"
placefile = "listsforprocessing/placenames-processed.csv"
writefile =  "ProQuestHearings/witnesslisttest-secondpass.tsv"
#writefile = "LexisNexis/test_processed.csv"

#the two below are actually created after running this script; they
#come from the "moreinfo" field. Am trying to see if can ID a few more by 
#iterating like this; below I'm using these to check that if the content of 
#moreinfo field is in morepos, try to insert into wpos; and same for org
morepos = "ProQuestHearings/moreposlist.txt"
moreorgs = "ProQuestHearings/moreorglist.txt"

print "Opening files..."

with open(workdir+csvfile) as f:
    witnessfile = f.read()
    filelines = [line for line in witnessfile.split('\n') if line.strip() != '']
    witnesslist = [fline.split('\t') for fline in filelines]
longest = len(max(witnesslist,key=len))


with open(workdir+statefile) as f:
    statenamelist = f.read().splitlines()
    statenamevariants = [line.split(',') for line in statenamelist]
    allpossiblestates = set([item.replace('.','').strip().lower() for sublist in statenamevariants for item in sublist])

with open(workdir+placefile) as f:
    places = set([line.lower() for line in f.read().splitlines()])
    
with open(workdir+jobfile) as f:
    joblist = set([line.lower() for line in f.read().splitlines()])
    
with open(workdir+morepos) as f:
    moreposl = set(f.read().splitlines())

with open(workdir+moreorgs) as f:
    moreorgsl = set(f.read().splitlines())
    
   
newwitnesslist = []
howmany = len(witnesslist)
counter = 0
replcount = 0 #just seeing if the moreorgs/morepos helps at all -- ha, all of 5

for witness in witnesslist:
#for hid,hdate,htitle,hcommittee,wlname,wfname,wpos,worg,city,state in witnesslist:
#[hid,hdate,hcongress,htitle,hcommittee,wlname,wfname,wpos,worg,city,state] + subjectlist
    hid = witness[0]
    hdate = witness[1]
    hcongress = witness[2]
    hsession = witness[3]
    htitle = witness[4]
    hcommittee = witness[5]
    wlname = witness[6]
    wfname = witness[7]
    wpos = witness[8]
    worg = witness[9]
    city = witness[10]
    state = witness[11]
    subjects = witness[12:]
    moreinfo = ""
     
    counter +=1
    print "Processing line {0} of {1}...".format(counter,howmany)
    
    
    # if committee is empty see if there's a commission
    if hcommittee.strip() == '':
        if 'Commission' in htitle or 'commission' in htitle:
            hcommittee = re.match('.*?(C|c)ommission',htitle).group(0)
            print "Commission: {0}".format(hcommittee),
            hcommittee = re.sub('^Report of\s*','',hcommittee)
            hcommittee = re.sub('.*the\s*','',hcommittee)
            hcommittee = re.sub('.*Hearings before\s*','',hcommittee)
            hcommittee = hcommittee.strip()
            print "Became committee: {0}".format(hcommittee)
            if hcommittee == "" or hcommittee=="Commission" or hcommittee=="commission": #if we had commission before and everything got deleted (e.g. "Report of commission appointed to ...")
                hcommittee = re.search('(C|c)ommission.*',htitle).group(0)
                print "Commission: {0}".format(hcommittee),
                hcommittee = re.sub(',.*','',hcommittee)
                print "Became committee: {0}".format(hcommittee)
        elif 'Select Committee' in htitle or 'Special Committee' in htitle:
            hcommittee = re.search('((Special)|(Select)).*',htitle).group(0)
            print "Select/special {0}".format(hcommittee),
            hcommittee = re.sub(',.*','',hcommittee)
            print "Became committee: {0}".format(hcommittee)
        else:
            hcommittee = htitle
        
                    
    #clean up junk like digits only
    if worg.strip().replace('.','').replace(',','').isdigit():
        worg = ''
    if wpos.strip().replace('.','').replace(',','').isdigit():
        wpos = ''
    
   
    # split position to see if possible to extract more info
    if  ';' in wpos: #e.g. Ill; representative OR grocer;clerk OR 
        wpospts = wpos.split(';')
        if wpospts[0].strip().lower() in allpossiblestates:
            state = wpospts[0].strip()
        potpos = wpospts[0].split()
        potpostwo = wpospts[1].split()
        if potpos[-1].strip().lower() in joblist or wpospts[0].strip().lower() in joblist:
            wpos = wpospts[0].strip()
            if potpostwo[-1].strip().lower() in joblist or wpospts[1].strip().lower() in joblist:
                moreinfo = '; '.join(wpospts[1:])
            else:
                worg = wpospts[1].strip()
                try: moreinfo = '; '.join(wpospts[2:])
                except: pass
        elif potpostwo[-1].strip().lower() in joblist or wpospts[1].strip().lower() in joblist:
            wpos = wpospts[1].strip()
            if worg.strip() == "":
                worg = wpospts[0].strip()
            else:
                moreinfo = wpospts[0].strip()
        else: #can't really be a positino if nothing matches
            if worg.strip() == "":
                worg = wpos.strip()
            else:
                moreinfo = wpos.strip()
    
    # split organization to see if possible to extract more info
    if ';' in worg: 
        worgpts = worg.split(';')
        if worgpts[0].strip().lower() in allpossiblestates:
            state = worgpts[0].strip()
        potposw = worgpts[0].split()
        potpostwow = worgpts[1].split()
        try:
            if potposw[-1].strip().lower() in joblist or worgpts[0].strip().lower() in joblist:
                wpos = worgpts[0].strip()
                worg = worgpts[1].strip()
                try: moreinfo = '; '.join(worgpts[2:])
                except: pass #so won't get errors if there's only 2 cells
            elif potpostwow[-1].strip().lower() in joblist or worgpts[1].strip().lower() in joblist:
                wpos = worgpts[1].strip()
                worg = worgpts[0].strip()
                try: moreinfo += '; '.join(worgpts[2:]) 
                except: pass
            else:
                worg = worgpts[0].strip()
                moreinfo +=  '; '.join(worgpts[1:])  
        except:
            pass

    
    #more cleanup of pos and org
    # first word is often a clue that can be used to fill out more fields
    
    if worg.strip() != '':
        worgpts = worg.split()
        if len(worgpts) > 1:
            if worgpts[0].strip().lower() == 'and':
                worg = ' '.join(worgpts[1:])
            if worgpts[0].strip().lower() == 'representing':
                worg = ' '.join(worgpts[1:])
                moreinfo += worgpts[0]
            #deleting 'former' makes possible to id if this should be wpos instead
            if worgpts[0].strip().lower() == 'former': 
                worg = ' '.join(worgpts[1:])
                moreinfo += worgpts[0]
        if len(worgpts) > 3:
            if worgpts[0].strip().lower() == 'also' and worgpts[1].strip().lower() == 'representing':
                worg = ' '.join(worgpts[2:])
                moreinfo += worgpts[0] + ' ' + worgpts[1]
            if worgpts[0].strip().lower() == 'formerly' and (worgpts[1].strip().lower() == 'with' or worgpts[1].strip().lower() == 'in' or worgpts[1].strip().lower() == 'of'):
                worg = ' '.join(worgpts[2:])
                moreinfo += worgpts[0] + ' ' + worgpts[1]
        #do again because above may have changed things
        worgpts = worg.split()
        #if begins with "NY association of..." or some such
        if  state.strip() == '' and worgpts[0].strip().lower() != 'washington' and worgpts[0].strip().lower() in allpossiblestates:
            state = worgpts[0].strip()
            if len(worgpts) == 1: #if there's only the state as organization
                worg = ''
        # see if can get state from "of NY" or such if not from beg.
        if state.strip() == '' and 'of' in worgpts:
            for i,w in enumerate(worgpts):
                if w == 'of':
                    if worgpts[i+1].strip().lower() in allpossiblestates:
                        state = worgpts[i+1]
        #if worg mistakenly records the position, not the organization
        if worgpts[0].lower() in joblist or worgpts[-1].lower() in joblist:
            if wpos.strip() == '': 
                wpos = worg
                worg = '' #since it was wrong
            else: 
                moreinfo += worg
                worg = ''               
            
                    
    if wpos.strip() != '':
        # two so can preserve case for writing but use lowercase for comparison
        wposptsch = [w.lower().strip() for w in wpos.split()]
        wpospts = [w.strip() for w in wpos.split()]           
        if 'representing' in wposptsch: #e.g. lawyer representing AFL
            for i,w in enumerate(wpospts):
                if w == 'representing':
                    if len(wpospts) > i+2: # if there are words after representing
                        if i > 0:
                            wpos = ' '.join(wpospts[:i])
                        else:
                            wpos = 'representing'
                        moreinfo += worg #save worg in case it's not empty
                        worg = ' '.join(wpospts[i+1:])
        #delete 'former', confuses things
        if wpospts[0].strip().lower() == 'former':
                wpos = ' '.join(wpospts[1:])
                moreinfo += worgpts[0]
        #if begins with "NY association of..." or some such
        if  state.strip() == '' and wpospts[0].strip().lower() != 'washington' and wpospts[0].strip().lower() in allpossiblestates:
            state = wpospts[0].strip()
        # see if can get state from "of NY" or such if not from beg.
        if state.strip() == '' and 'of' in wpospts:
            for i,w in enumerate(wpospts):
                if w == 'of':
                    if wpospts[i+1].strip().lower() in allpossiblestates:
                        state = wpospts[i+1]
        
    #do the same stuff as for worgparts for moreinfo
    if moreinfo.strip() != '': 
       mipts = moreinfo.split()
       if state.strip() == '' and mipts[0].strip().lower() != 'washington' and mipts[0].strip().lower() in allpossiblestates:
           state = mipts[0].strip()
        # see if can get state from "of NY" or such if not from beg.
       if state.strip() == '' and 'of' in mipts:
           for i,w in enumerate(mipts):
               if w == 'of' and len(mipts) > i+1:
                   if mipts[i+1].strip().lower() in allpossiblestates:
                       state = mipts[i+1]

    
    # and do the some fixing for city field - sometimes position has ended up in city
    if city.strip() != '': 
       if city.strip().lower() in joblist or city.strip().islower():
           if wpos.strip() == '':
               wpos = city
           else:
               moreinfo += city
           city = ''


    # fix incorrectly expanded Amer
    if worg:
        worgline = worg.split()
        if worgline[0].strip() =='America':
            newworgline = ['American']
            newworgline += worgline[1:]
            worg = " ".join(newworgline)
            
# This shouldn't be necessary anymore
#        if worgline[-1].strip().lower() == 'co':
#            templine = ['Company']
#            newworgline = worgline[:-1] + templine
#            worg = " ".join(newworgline)
    
    #if the word 'company' is present in position, probably it's actually the org field
    if re.search('company',wpos,flags=re.I) is not None:
        moreinfo += worg 
        worg = wpos
        wpos = ''
    #try to get things like General Motors from "attorney for General Motors"
    #there will be some false matches but it's not that bad since we're only saving this
    #in case there isn't anything in the org field
    if wpos:
        wposline = wpos.split()
        if len(wposline) > 1:
            for idx, wposword in enumerate(wposline):
                if wposword.strip() == 'for':
                    wpos = " ".join(wposline[:idx])
                    if worg.strip() == '':
                        worg = " ".join(wposline[idx+1:])
                        worg = worg.strip()
                        moreinfo += wpos #just so we see how it was constructed
                        
                   
                
            
    #get politicians identified and parties fixed
    if '(Representative' in wfname:
        wpos = 'Representative'
        wfname = re.match('(.*?)\(',wfname).group(1)
    if '(Senator' in wfname:
        wpos = 'Senator'
        wfname = re.match('(.*?)\(',wfname).group(1)
    
    #parties: U seems to be for territories, I is probably independent, ignoring those
    partymatch = re.search('(R|D|U|F|FL|P|S|I) -([A-Z]+)',worg)
    if partymatch:
        if partymatch.group(1) == 'D':
            worg = 'Democratic Party'
        elif partymatch.group(1) == 'R':
            worg = 'Republican Party'
        elif partymatch.group(1) == 'F':
            worg = 'Farmer-Labor Party'
        elif partymatch.group(1) == 'FL':
            worg = 'Farmer-Labor Party'
        elif partymatch.group(1) == 'P':
            worg = 'Progressive Party' 
        elif partymatch.group(1) == 'S':
            worg = 'Socialist Party' 
        state = partymatch.group(2)
    partymatch = re.search('(R|D|U|F|FL|P|S|I) -([A-Z]+)',city)
    if partymatch:
        if partymatch.group(1) == 'D':
            worg = 'Democratic party'
        elif partymatch.group(1) == 'R':
            worg = 'Republican Party'
        elif partymatch.group(1) == 'F':
            worg = 'Farmer Labor Party'
        elif partymatch.group(1) == 'FL':
            worg = 'Farmer Labor Party'
        elif partymatch.group(1) == 'P':
            worg = 'Progressive Party'
        elif partymatch.group(1) == 'S':
            worg = 'Socialist Party'
        state = partymatch.group(2)
        city = ''
    
        
#    if wpos.strip() == "":
#        if worg.strip():
#            # see if wpos mistakenly in worg
#            elements = worg.split()
#            first = elements[0]
#            last = elements[-1]
#            if first.endswith('s'): first = first[:-1] # to eliminate plurals            
#            if last.endswith('s'): last = last[:-1]
#            if first in joblist or last in joblist:
#                wpos = worg.strip()
#                worg = ''  

    if wpos.strip() == "":                  
        cand = moreinfo.strip()
        cand = cand.replace('also representing','')
        cand = cand.replace('representing','')
        cand = cand.strip()
        if cand.lower() in moreposl:
            wpos = cand
            replcount += 1

    if worg.strip() == "":
        cand = moreinfo.strip()
        cand = cand.replace('also representing','')
        cand = cand.replace('representing','')
        cand = cand.strip()
        if cand.lower() in moreorgsl:
            wpos = cand
            replcount += 1
        
    #get year
    if hdate:
        hyearsearch = re.search('\d{4}',hdate,flags=0)
        if hyearsearch is not None:
            hyear = hyearsearch.group(0)
        
    # fix state format - standardize to AZ, CA...
    # doing this last as some of the more info above creates states
    if state != "":
        for line in statenamevariants:
            for statevar in line:
                if state.lower().strip('.').strip() == statevar.lower().strip('.').strip():
                    state = line[0]  


    newlist = [hid,hyear,hdate,hcongress,hsession,htitle,hcommittee,wlname,wfname,wpos,worg,moreinfo,city,state] + subjects
    newwitnesslist.append(newlist)

stringlist = []
for wlist in newwitnesslist:
    wstring = "\t".join(wlist)
    stringlist.append(wstring)
witnessestext = "\n".join(stringlist)

with open(workdir+writefile, 'w') as f:
    f.write(witnessestext)   