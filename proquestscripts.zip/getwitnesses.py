# -*- coding: utf-8 -*-
"""
Created on Wed Nov 12 10:09:24 2014

@author: Vilja

This extracts information from the html files that contain ProQuest Congressional
hearing metadata, including basics like title and date but also Congress, Subjects,
and Witnesses.
"""

from bs4 import BeautifulSoup
from collections import Counter
import os, re, sys

#the below were for trying to make BeautifulSoup work with pypy, I don't think it worked
sys.path.insert(0, '/usr/local/lib')
sys.path.insert(0, os.path.expanduser('~/lib'))
sys.path.insert(0,'/Users/vilja/anaconda/lib/python2.7/site-packages/bs4/')


rootdir = "/Users/vilja/work/research/digital/"
#mydir = rootdir + "LexisNexis/metatest/"
mydir = rootdir + "ProQuestHearings/ProquestHTMLsample/"

witnessfilename = rootdir + "ProQuestHearings/witnesslist-test.tsv"
sucountsfn = rootdir + "ProQuestHearings/sucounts-test.csv"

#witnessfilename = rootdir + "LexisNexis/wittest.csv"


witnessnames = []
witnesslist = []
allsubjects = []

fn = 0
for item in os.listdir(mydir):
    
    fn +=1
    print "Processing file number %s" % (fn) 
    if os.path.isfile(mydir+item) :
        with open(mydir+item) as f0:
            newfile = f0.read()
        soup = BeautifulSoup(newfile,"html.parser")
        hearingid = ""
        hearingid = soup.find(text=re.compile("Hearing Id",flags=re.IGNORECASE))
        if not hearingid:
            hearingid = soup.find(text=re.compile("Serial Set Id",flags=re.IGNORECASE))
        if not hearingid:
            hearingid = soup.find(text=re.compile("CIS number",flags=re.IGNORECASE))
        try: #the try's are to prevent freezign on errors if patterns don't match
            hearingtag = hearingid.find_parent("div")
            hid = hearingtag.find_next_sibling("div").string.extract()
        except:
            pass
        committee = ""
        committeesearch = soup.find(text=re.compile("Committee:|Agency:",flags=re.IGNORECASE))
        try:
            commtag = committeesearch.find_parent("div")
            committee = commtag.find_next_sibling("div").string.extract()
        except:
            committee = ""
        title = ""
        titlesearch = soup.find(text=re.compile("Title:",flags=re.IGNORECASE))
        try:
            titletag = titlesearch.find_parent("div")
            title = titletag.find_next_sibling("div").string.extract()
        except:
            pass
        date= ""
        datesearch = soup.find(text=re.compile("((Hearing)|(Pub)|(Doc)|(Document))*\s*Date:",flags=re.IGNORECASE))
        try:
            datetag = datesearch.find_parent("div")
            date = datetag.find_next_sibling("div").string.extract()
        except:
            pass
        #subjecttag = soup.find(text=re.compile("Subjects",flags=re.IGNORECASE))
        maxsubjects = 0
        subjecttag = soup.find(attrs={"name":"Subjects"})
        try:
           subjectdiv = subjecttag.next_sibling
           subjects = subjectdiv.find(attrs={"class":"segFull fulltext"}).contents[1]
           subjectlist = [subject.strip() for subject in subjects.split(';')]
           allsubjects += subjectlist
           if len(subjectlist) > maxsubjects:
               maxsubjects = len(subjectlist)
        except:
            pass
        congresstag = soup.find(attrs={"name":"Congress Session"})
        cstring = ""
        try:
            congressdiv = congresstag.next_sibling
            cstring = congressdiv.find(attrs={"class":"segColR"}).string.extract()
            cstring = re.sub('\s+','',cstring)
        except:
            pass
       # witnesses = soup.find_all(re.compile("segFull^ "))
        witnesses = soup.find_all(attrs={"class":"segFull"})
        index = 0
        for witness in witnesses:
            witlist = []
            wit = str(witness)
            pattern = '<div class="segFull">([^<].*?)</div>'
            m = re.match(pattern,wit)
            if m:
                columns = [col.strip() for col in m.group(1).split(',')]
                #make a separate list of witnesses
                try:
                    #this names bit is just to create a separate list of names, not for inclusion in full witness file
                    names = (columns[0] + ' ' + columns[1], columns[0], columns[1])
                    witnessnames.append(names) 
                    # break down columns as correctly as possibel
                    index += 1
                    if not columns[0].isupper():
                        columns.insert(0, ' ')
                    third = columns[2]
                    if 'p. ' in third:
                        columns.insert(2,' ')
                    elif third[0].isupper():
                        columns.insert(2,' ')
                    elif 'representing' in third:
                        reprmatch = re.match('.*?representing\s*(.*)',third,flags=0)
                        thirdnew = reprmatch.group(1)
                        columns.insert(2, 'representing')
                        columns[3] = thirdnew
                    elif ',' in third:
                        thirdlist = third.split(',')
                        columns.pop(2)
                        for index, item in enumerate(thirdlist):
                            columns.insert(2+index,item) 
                    fourth = columns[3]
                    if 'p. ' in fourth:
                        columns.insert(3, ' ')
                    if not ' Co' in fourth:
                        columns.insert(3, ' ')
                except:
                    try:
                        columns = m.group(0)
                    except:
                        columns = ""
                if hearingid:
                    witlist.append(hid)
                else: 
                    witlist.append('')# + '\t' #these keep alignment right 
                if titlesearch:
                    witlist.append(title)
                else: 
                    witlist.append('')
                if datesearch:
                    witlist.append(date)
                else: 
                    witlist.append('')
                if congresstag:
                    witlist.append(cstring)
                else: 
                    witlist.append('')
                witlist.append(committee)
                witlist += columns
                for i in range(maxsubjects):
                    if subjectlist and i < len(subjectlist):
                        witlist.append('Subject: ' + subjectlist[i])
                witnessline = '\t'.join(witlist)
                witnesslist.append(witnessline)
             
             
#witlines = witlist.splitlines()
witlinesuniq = list(set(witnesslist))

witlistwrite = '\n'.join(witlinesuniq)


# subject counts
subjectscount = Counter(allsubjects)
subjectscounts = [k + "," + str(v) for k,v in subjectscount.iteritems()]
subjectscountstxt = '\n'.join(subjectscounts)

with open(witnessfilename, 'w') as f:
    f.write(witlistwrite)

with open(sucountsfn,'w') as f:
    f.write(subjectscountstxt)
#witnessnames2 = list(set(witnessnames))
            

    
#with open(filename,'w') as f:
 #   f.write(addresses)