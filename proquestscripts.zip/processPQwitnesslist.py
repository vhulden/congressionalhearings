# -*- coding: utf-8 -*-
"""
Created on Oct 2, 2018

@author: vilja

This is a revision of the processwitnesslist.py written for the scraped ProQuest data.
This is for the official ProQuest XML data.

The main intent here is to try to fill out the pos and org fields, 
and city and state as well if possible. For the majority of the witnesses,
this was in the text tag, and that is a jumble of information.

This does not standardize states, that is left to the secondpass script. 
From that I think I'll try to lob off the identification stuff into a separate
script.

[Original description of old script: ] The basic function of this script is to attempt to get the order of the fields
right; the statefile and place file etc. simply help with that. The next
script (processwitnesslist-cleanup.py) then tries to split up these fields when they
contain additional or incorrect informatin, and fixes states. After that comes the script
that attempts to identify witness affiliations.
"""
import re,codecs,os
from collections import Counter

workdir = "/Users/vilja/work/research/digital/ProQuestHearings/reprocessed012019/"
csvfile = "witnesslist-newxml_abbrfixed.tsv"
#csvfile = "LexisNexis-AHA/testlist.csv"
jobfile = "../../listsforprocessing/jobtitles-unique.txt"
statefile = "../../listsforprocessing/states.csv"
placefile = "../../listsforprocessing/placenames-processed.csv"
writefile = workdir + "witnesslist-newxml_processed.tsv"
if os.path.exists(writefile): os.remove(writefile) #because appended to

orgsfile = workdir + "ProQuestHearings/organizations.txt"
posfile = workdir + "ProQuestHearings/positions.txt"

#writefile = "LexisNexis-AHA/testlist-processed.csv"


print "Opening files..."

#this probably won't be possible because it's 1.1G. can I get the longest somehow?
# do I need it?
#with open(workdir+csvfile) as f:
#    witnessfile = f.read()
#    filelines = [line for line in witnessfile.split('\n') if line.strip() != '']
#    witnesslist = [fline.split('\t') for fline in filelines]
#longest = len(max(witnesslist,key=len))


with open(workdir+statefile) as f:
    statenamelist = f.read().splitlines()
    statenamevariants = [line.split(',') for line in statenamelist]
    allpossiblestates = set([item.replace('.','').strip().lower() for sublist in statenamevariants for item in sublist])

with open(workdir+placefile) as f:
    places = set([line.lower() for line in f.read().splitlines()])
    
with open(workdir+jobfile) as f:
    joblist = set([line.lower() for line in f.read().splitlines()])
    
#list of what's going to go into the new witnesslist as defined by maneuvers
#below; give empty values so there's no problem if not all are defined for all witnesses





newwitnesslist = []
#howmany = len(witnesslist)

#for idx, w in enumerate(witnesslist):
counter = 0
organizations = []
positions = []
with codecs.open(workdir+csvfile,encoding='utf8') as f:
    for line in f:
        counter += 1
        w = line.split('\t')
        #reset every time and ensure they're at least defined
        HID = w[0]
        title = w[1]
        date = w[2]
        year = w[3]
        congress = w[4]
        session = w[5]
        branch = w[6]
        committee = w[7]
        subcommittee = w[8]
        lname = w[9]
        fname = w[10]
        hon = w[11]
        suffix = w[12]
        pos = w[13]
        org = w[14]
        city = w[15]
        state = w[16]
        addl = w[17]
        subjects = w[18:]
        
        print "Processing line {0} ...".format(counter)
        # examine addl since that's where there is more info
        # split it by comma and try to identify different parts.
        cell = addl
        if cell.strip(): #if it's not empty
            if ',' in cell:
                cellcontent = cell.split(',')
                if re.match('p\.\s*[0-9]+',cellcontent[0].strip(),flags=0) is None:
                    oldcellpart = ""
                    for cellpart in cellcontent:
                        found = 0
                        scellpt = cellpart.strip(';,.').strip().lower() #cell variant for searching to ignore case
                        if scellpt in joblist and pos.strip() == "":
                            pos = cellpart.strip(';,.').strip()
                            found = 1
                        elif scellpt in allpossiblestates and state.strip() == "":
                            state = cellpart.strip(';,.').strip()
                            found = 1
                        elif scellpt in places and city.strip() == "":
                            city = cellpart.strip(';,.').strip()
                            found = 1
                            # if find city and pos is filled, part preceding city is probably the org
                            if pos.strip != "":
                                if org == "":
                                    org = oldcellpart
                        oldcellpart = cellpart
                            
                        if found == 0: # this is the default, if nothing matches
                            if pos.strip() == "": 
                                pos = cellcontent[0].strip()
                                if org.strip() == "": org = ",".join(cellcontent[1:]).strip() 
                            else: #if there is a pos already, put all in org
                                if org.strip() == "":  org = ",".join(cellcontent).strip()
                               # print org
                        
            #then basically do the same options if there are no commas in this cell
            elif re.match('\s*p\.\s*[0-9]+',cell,flags=0) is None:
                scell = cell.strip(',.').strip().lower() #cell variant for searching to ignore case
                if scell in joblist and pos.strip() == "":
                    pos = cell.strip()
                elif scell in allpossiblestates and state.strip() == "":
                    state = cell.strip()
                elif scell in places and city.strip() == "":
                    city = cell.strip()
                elif scell.split()[0].strip() == 'representing':
                    if pos.strip() == "": pos = cell.split()[0].strip().strip(',')
                    #if org.strip() == "": org = " ".join(cell.split()[1:]).strip()
                    #no, actually, replace the org even if it exists
                    if org.strip() == "": org = " ".join(cell.split()[1:]).strip()
                else: #default is to assume it's position description? is that wise? isn't it more likely to be org? maybe not if pos is empty
                    if pos.strip() == "": pos = cell.strip()
                    else: 
                        if org.strip() == "": org = cell.strip()
            
            #some final cleanup to do following:            
            if pos.strip() != "":
                #get rid of page numbers in pos
                org = re.sub('p\.\s*?[0-9\-,]+\.*','',org)
                #if pos has representing then the part after it should be in org
                if not re.search('also\s*representing',org): #only representing not alsos
                    m = re.search('.*?representing\s*(.*?)$',pos)
                    if m:
                        org = m.group(1)
                #if after this there are ; chars, that's probably not something that
                # should be in pos
                pos = re.sub(';.*$','',pos)
                pos = pos.strip(',. ')
            
            
            if org.strip() != "":
                #get rid of page numbers in org
                org = re.sub('p\.\s*?[0-9\-,]+\.*','',org)
                #make sure that org is the one represented, as in "representing X" should be X
                if not re.search('also\s*representing',org): #only representing not alsos
                    org = re.sub('.*?representing\s*(.*?)$','\\1',org)
                #if after this there are ; chars, that's probably additional info after
                #an already defined org. delete that.
                org = re.sub(';.*$','',org)
                org = org.strip(',. ')
                #and if org has a comma, the section after the comma is likely to be the real org
                # as in 'local 43, AFSCME' or 'trustees board, Some Org'
                # ... except if part after comma is Inc or Incorporated.
                if ',' in org:
                    orgpts = org.split(',')
                    if len(orgpts) > 1:
                        if not any('Inc' in pt for pt in orgpts[1:]):
                            #if no parts are a state
                            if not any(True for x in orgpts if x.strip().lower() in allpossiblestates):
                            # any(pt.strip().lower() for pt in allpossiblestates):
#                            if len(orgpts[1].split()) > 1:
#                                org = orgpts[1].strip(';,.').strip()
#                            else:
                                org = ','.join(orgpts[1:]).strip(';,.').strip()
                            else:   
                                for idx,pt in enumerate(orgpts):
                                    if pt.lower().strip() in allpossiblestates: 
                                        if len(orgpts)-(idx+1) != 0:
                                            org = ','.join(orgpts[idx+1:]).strip(';,. ')
                                        else:
                                            org = ','.join(orgpts[:idx-1]).strip(';,. ')
                                        break
                
        
            
            #if state is still empty after all of the above, try first word of addl since that often contains state as in "MN association for..."
            if state.strip() == "": 
                potst = cell.split()[0].strip(';,.').strip()
                if potst.lower() in allpossiblestates:
                    state = potst
            #or try from org if that didn't help
            if state.strip() == "": 
                if org.strip() != "":
                    potst = org.split()[0].strip(';,.').strip()
                    if potst.lower() in allpossiblestates:
                        state = potst
                
        
    
       
        #and then, finally, put everything in a list
        newwline = [HID, title, date, year, congress, session, branch, committee, subcommittee, lname, fname, hon, suffix, pos, org, city, state, addl] + subjects
        organizations.append(org)
        positions.append(pos)
        newwlinetxt = '\t'.join(newwline)
        with codecs.open(writefile,'a',encoding='utf8') as f1:
            f1.write(newwlinetxt)
        
