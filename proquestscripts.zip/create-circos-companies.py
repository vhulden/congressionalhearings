# -*- coding: utf-8 -*-
"""
Created on Thu Nov 26 13:37:31 2015

@author: Vilja Hulden

This takes in a Congressional committee witness file (created by the scripts
getwitnesses, processwitnesslist, processwitnesslist-secondpass) and creates a 
file that Circos tableviewer can make a the karyotype out of. The input is the full
info in the witness list, of which only company (or any organization really) 
and the Congressional committee are preserved, and the output is the table that
looks like this:
    
    	X 		House_Labor House_Judiciary Senate_Labor Senate_Judiciary

Witness1		20				0				0              0
Witness2		10				20				0             20

Note: the script as laid out below considers "witness" to be an organization rather
than an individual, and skips all entries that do not have an organization field. 
This could of course be modified to focus on individual witnesses etc.

Also output a few other files that lists all the companies (organizations) and 
all the committees in a form without spaces; these too are needed for Circos 
tweaks.

Note that the committee name is simplified to the very basic: e.g. House_Judiciary
rather than House_Judiciary_Subcommittee_On... etc. This is done to make the 
end product, i.e., the Circos image, more legible. One could of course do this 
in a more complex way, grouping by main committee or something like that.

Also note kluge below with D-MA / R-IN and so on; these should really be fixed
in the scripts that create the witness list.
 """
import re
from collections import defaultdict

workdir = "/Users/vilja/work/digitalresearch/"
#csvfile = "LexisNexis/witnessprocshort.csv"
csvfile = "LexisNexis/witnesslists-laborcomms/businessnotNAMwitnesses-laborcomms.csv"
writefile = "LexisNexis/witnesslists-laborcomms/committee-co-busnotNAM.csv"
writetable = "LexisNexis/witnesslists-laborcomms/busnotNAM-table.csv"
writeyeartable = "LexisNexis/allhearings/yearcomm-table.csv"
writereps = "LexisNexis/allhearings/selectcommcos.txt"
#csvfile = "LexisNexis/witnesslist1877-1932_final.csv"
#writefile = "LexisNexis/allhearings/selectcommittee-co-simplified-org.csv"
#writetable = "LexisNexis/allhearings/org-table.csv"
#writeyeartable = "LexisNexis/allhearings/yearcomm-table-org.csv"
#writereps = "LexisNexis/allhearings/selectcommcos-org.txt"
# the file below is used for circos to help organize the image
# note that it needs to be tweaked so newlines are replaced with ; and 
# then the result is inserted into the chromosomes and chromosomes_order
# lines in the main conf file. 
writecomms = "LexisNexis/allhearings/selectcomms-cos.txt"
writeyears = "LexisNexis/allhearings/years.txt"
writeyearcounts = "LexisNexis/allhearings/yearcounts.csv"
writecommcounts = "LexisNexis/allhearings/commcounts.csv"

#writecomms = "LexisNexis/allhearings/selectcomms-cos-org.txt"
#writeyears = "LexisNexis/allhearings/years.txt"
#writeyearcounts = "LexisNexis/allhearings/yearcounts.csv"
#writecommcounts = "LexisNexis/allhearings/commcounts.csv"

with open(workdir+csvfile) as f:
    witnessfile = f.read()
    filelines = [line for line in witnessfile.split('\n') if line.strip() != '']
    witnesslist = [fline.split('\t')[:11] for fline in filelines] #truncate so that won't need to put a ton of _'s into for loop
    

newlist = []
committeelist = []
replist = []
yearlisttemp = [] #this is temporary, new yearlist created below including all years b/w start and end below
committeedict = defaultdict(dict)
yeardict = defaultdict(dict)
for _,year,_,_,_,_,committee,lname,fname,pos,worg in witnesslist:
    # choose to either skip all without organization or where org is digit OR 
    # replace them with lname fnmae or to mark them as other
    skip = 0  
    repl = 1
    replworker = 1
    if worg.strip() == '' or "".join(worg.split()).isdigit(): 
        if skip == 0 and repl==0 and replworker == 0:
            worg = "other"
        elif replworker:
            if pos.strip() != "":
                worg = pos
        elif repl and lname.strip() != "":
            worg = lname + ' ' + fname
        elif repl and lname.strip() == "":
            worg = "other"
        else:
            continue
        
    worg = worg.lower().strip()
    worg = re.sub("[,.;']+",'',worg,count=0,flags=0)
    worg = re.sub('\s+','-',worg,count=0,flags=0)

    # here we simplify the committee name. 
    # Subcommittees are ignored whether they appear before or after the main committee
    # only one (the first) committee is preserved even if the list contains several
    commatch = re.match('.*?(Committee on)\s*(the)*\s*(.*?)($|(Committee)|(Subcommittee))',committee,flags=0) 
    if commatch is not None:
        comm = commatch.group(3)
        comm = re.sub("[,.;' ]+",'_',comm,count=0,flags=0)
        comm = re.sub('_$','',comm,count=0,flags=0)
    else:
        comm = "Undefined"

    # OK, next set the counts in the dictionary that will become the table
    # If we've seen this worg at this committee before, we add to its count
    # Otherwise we establish the first instance of this worg at this committee.
    # At the same time, we want to create a list that gets us the raw counts of 
    if comm in committeedict and worg in committeedict[comm]:
        committeedict[comm][worg] += 1
    else:
        committeedict[comm][worg] = 1
        
    
        
    # then do the same thing for a committee-year table
    year = int(year)
    if year in yeardict and comm in yeardict[year]:
        yeardict[year][comm] += 1
    else:
        yeardict[year][comm] = 1
        
    # I don't actually remember what the purpose of this is
    newentry = [comm,worg]
    newentrytxt = "\t".join(newentry)
    newlist.append(newentrytxt)
    # these list all the committees that appeared and all the reps that appeared
    committeelist.append(comm)
    replist.append(worg)
    yearlisttemp.append(year)
    
uniqcommlist = list(set(committeelist))
uniqreplist = list(set(replist))
startyear = int(min(yearlisttemp))
endyear = int(max(yearlisttemp))
yearlist = []
for year in range(startyear,endyear+1):
    yearlist.append(year)

yearlist.sort()

yearstrings = [str(year) for year in yearlist]

yearlisttxt = "\n".join(yearstrings)

# convert committee dictionary into a form that is legible by circos
# columns are committees, rows are represents

# first line: X Committee1 Committee2 Committee 3
tableline1 = 'X'
for comm in uniqcommlist:
    tableline1 += ' ' + comm

# line 2 and subsequent lines:
# start with rep name, then go through list of committees
# if the committeedict has something for committeedict[comm][rep],
# write that number into the line, else write a 0
# so the result is 
# rep 0 2 4 0 0 0 0 1 ...
tablecommlines = []
includedcomms = []
includedreps = []
for rep in uniqreplist:
    tableline2 = rep
    for comm in uniqcommlist:
        if committeedict.has_key(comm):
            if committeedict[comm].has_key(rep):
                includedcomms.append(comm)                
                includedreps.append(rep)
                tableline2 +=  ' ' + str(committeedict[comm][rep])
            else:
                tableline2 += ' 0'
        else:
            tableline2 += ' 0'     
    tablecommlines.append(tableline2)

#add the first line with the committees
tablecommlines.insert(0,tableline1)

""" YEAR TABLE
   # convert year dictionary into a form that is legible by circos
   # columns are years, rows are committees"""

# first line: X 1885 1886 1887...
ytableline1 = 'X'
for year in yearlist:
    ytableline1 += ' ' + str(year)

# line 2 and subsequent lines:
# start with committee name, then go through list of years
# if the yeardict has something for yeardict[year][comm],
# write that number into the line, else write a 0
# so the result is 
# comm 0 2 4 0 0 0 0 1 ...
ytablecommlines = []
for comm in uniqcommlist:
    ytableline2 = comm
    for year in yearlist:
        if yeardict.has_key(year):
            if yeardict[year].has_key(comm):
                ytableline2 +=  ' ' + str(yeardict[year][comm])
            else:
                ytableline2 += ' 0'
        else:
            ytableline2 += ' 0'     
    ytablecommlines.append(ytableline2)

#add the first line with the years
ytablecommlines.insert(0,ytableline1)

#let's get a count of which years see a lot of committee activity

ycountslist = []
for year in yeardict:
    totalcount = 0
    for committee in yeardict[year]:
        totalcount += yeardict[year][committee]
    ycountslist.append(str(year) + "," + str(totalcount))


# let's also get a count of how many times a committee is involved in a hearing
ccountslist = []
for comm in uniqcommlist:
    totalcount = 0
    for rep in committeedict[comm]:
        totalcount += committeedict[comm][rep]
    ccountslist.append(comm + "," + str(totalcount))
    
    


newlist.sort()  

includedcomms = list(set(includedcomms))
includedreps = list(set(includedreps))

newlisttxt = '\n'.join(newlist)
includedcommtxt = '\n'.join(includedcomms)
includedreptxt = '\n'.join(includedreps)
commlinestxt = '\n'.join(tablecommlines)
yearlinestxt = '\n'.join(ytablecommlines)
yearcountstxt = '\n'.join(ycountslist)
ccountstxt = '\n'.join(ccountslist)

with open(workdir+writefile,'w') as f:
    f.write(newlisttxt)

with open(workdir+writetable,'w') as f:
    f.write(commlinestxt)

with open(workdir+writeyeartable,'w') as f:
    f.write(yearlinestxt)

    
with open(workdir+writecomms,'w') as f:
    f.write(includedcommtxt)

with open(workdir+writereps,'w') as f:
    f.write(includedreptxt)
    
    
with open(workdir+writeyears,'w') as f:
    f.write(yearlisttxt)
    
with open(workdir+writeyearcounts,'w') as f:
    f.write(yearcountstxt)
    
with open(workdir+writecommcounts,'w') as f:
    f.write(ccountstxt)