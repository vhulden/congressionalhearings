# -*- coding: utf-8 -*-
"""
Created on Wed Nov 25 10:18:40 2015

@author: vilja
"""

import re

workdir = "/Users/vilja/work/research/digital/"
#csvfile = "LexisNexis/test_processed.csv"
csvfile = "ProQuestHearings/witnesslisttest_processed.tsv"
writefile = "ProQuestHearings/witnesslisttest_final.tsv"
statefile = "listsforprocessing/states.csv"
#writefile = "LexisNexis/test_moreprocessed.csv"

with open(workdir+csvfile) as f:
    witnessfile = f.read()
    filelines = [line for line in witnessfile.split('\n') if line.strip() != '']
    witnesslist = [fline.split('\t') for fline in filelines]

longest = len(max(witnesslist,key=len))

with open(workdir+statefile) as f:
    statenamelist = f.read().splitlines()
    statenamevariants = [line.split(',') for line in statenamelist]

newwitnesslist = []
howmany = len(witnesslist)
counter = 0

for witness in witnesslist:
#for hid,hdate,htitle,hcommittee,wlname,wfname,wpos,worg,city,state in witnesslist:
#[hid,hdate,hcongress,htitle,hcommittee,wlname,wfname,wpos,worg,city,state] + subjectlist
    hid = witness[0]
    hdate = witness[1]
    hcongress = witness[2]
    hsession = witness[3]
    htitle = witness[4]
    hcommittee = witness[5]
    wlname = witness[6]
    wfname = witness[7]
    wpos = witness[8]
    worg = witness[9]
    city = witness[10]
    state = witness[11]
    subjects = witness[12:]
    
    
    counter +=1
    #print "Processing line {0} of {1}...".format(counter,howmany)
    # first a couple of fixes: if committee is empty see if there's a commission
    # and fix state format - standardize to AZ, CA...
    
    #add hyear - did this sometime earlier but am adding now as that's misplaced
    # 9/27/18
    if hdate.strip() !='':
        hyear = re.search('\d{4}',hdate).group(0)
    if hcommittee.strip() == '':
        if 'Commission' in htitle or 'commission' in htitle:
            hcommittee = re.match('.*?(C|c)ommission',htitle).group(0)
            print "Commission: {0}".format(hcommittee),
            hcommittee = re.sub('^Report of\s*','',hcommittee)
            hcommittee = re.sub('.*the\s*','',hcommittee)
            hcommittee = re.sub('.*Hearings before\s*','',hcommittee)
            hcommittee = hcommittee.strip()
            print "Became committee: {0}".format(hcommittee)
            if hcommittee == "" or hcommittee=="Commission" or hcommittee=="commission": #if we had commission before and everything got deleted (e.g. "Report of commission appointed to ...")
                hcommittee = re.search('(C|c)ommission.*',htitle).group(0)
                print "Commission: {0}".format(hcommittee),
                hcommittee = re.sub(',.*','',hcommittee)
                print "Became committee: {0}".format(hcommittee)
        elif 'Select Committee' in htitle or 'Special Committee' in htitle:
            hcommittee = re.search('((Special)|(Select)).*',htitle).group(0)
            print "Select/special {0}".format(hcommittee),
            hcommittee = re.sub(',.*','',hcommittee)
            print "Became committee: {0}".format(hcommittee)
        else:
            hcommittee = htitle
    if state != "":
        for line in statenamevariants:
            for statevar in line:
                if state.lower().strip('.').strip() == statevar.lower().strip('.').strip():
                    state = line[0]
                
    
    
    # Then start trying to identify
    
    wtype = '' #define worker, company, politician, organization, farm organization, media (incl broadcasting), detective, police, politics, judiciary, executive, religious   --- organization incl. empl. but not union, which is in worker; organization also includes religious organizations and churches
    wrep = '' #define labor, business, public, government, enforcement ---government includes politics and executive


    
    
    # PRESS WPOS
    if  re.search('(editor)|(publisher)|(correspondent)|(newspaperman)|(newspaper man)|(journalist)',wpos,flags=re.I) is not None:
        wtype = 'media'
        if re.search('(labor)|(socialist)|(work)',worg,flags=re.I) is not None:
            wrep = 'labor'
        else:
            wrep = 'public'    
            
    #POLITICS WPOS
    if re.search('(representative)|(senator)',wpos,flags=re.I) is not None:
        wtype = 'politics'        
        wrep = 'government'
    if re.search('(democratic)|(republican)',wpos,flags=re.I) is not None:
        wtype = 'politics'
        wrep = 'public'
        
    # PUBLIC WPOS
    if re.search('(pastor)|(bishop)|(reverend)|(chaplain)|(missionary)',wpos,flags=re.I) is not None:
        wtype = 'religious'
        wrep = 'public'
        
    if re.search('(professor)|(historian)|(principal)|(lecturer)|(economist)|(statistician)',wpos,flags=re.I) is not None:
        wrep = 'public'
    
    # PUBLIC #if these mistakenly in wpos
    if re.search('(adventists)|(american legion)|(archdiocese)|(bishop)|(catholic)|'\
                '(charities)|(child)|(christian)|(church)|(civic)|(college)|'\
                '(consumers league)|(disabled)|(education)|(evangelical)|'\
                '(federation of women)|(hebrew)|(hibernian)|(hull house)|(home economics)|'\
                '(hospital)|(institution)|(invalid)|(jewish)|(league)|'\
                '(library)|(marine society)|(national woman)|(of women)|'\
                '(order of moose)|(patriotic order)|(preparedness)|'\
                '(prohibition)|(protestant)|(public health)|(pure food)|'\
                '(race congress)|(relief)|(rotary)|(russell sage)|'\
                '(scouts)|(society of friends)|(statistical association)|'\
                '(suffrage)|(synagogue)|(taft club)|(temperance)|'\
                '(tuberculosis)|(university)',worg,flags=re.I) is not None:
        worg = wpos
        wpos = ''
    
    # PRINTER: ^(public)\s*printer
    # WORKER WPOS
    if re.search('(blacksmith)|(cigar maker)|(cigarmaker)|(cooper)|(repairer)|(telegrapher)|(carpenter)|(slaughterer)|(butcher)|(tinner)|(dressmaker)|(coal man)|(conductor)|(cutter)|(cloak maker)|(employee)|(grocer)|(labor)|'\
                '(laborer)|(machinist)|(\Wmechanic\W)|(miner)|'\
                '(molder)|(motorman)|(plumber)|(printer)|(striker)|(tailor)|(telegrapher)'\
                '(type founder)|(worker)',wpos,flags=re.I) is not None:
        wtype = 'worker'
        wrep = 'labor'

    #PUBLIC - FARM WPOS
    if re.search('(farmer)|(grower)|(raiser)',wpos,flags=re.I) is not None:   
        wtype = 'agriculture'
        wrep = 'public'

        
    # GOVERNMENT WPOS
    if re.search('(judge)|(attorney general)|(district attorney)|(justice)',wpos,flags=re.I) is not None:
        wtype = 'judiciary'
        wrep = 'government'
    if re.search('(adjutant general)|(adjutant-general)|(postmaster)|(postmistress)|(superintendent of mails)|(governor)|(mayor)|'\
                 '(attorney general)|(commissioner of immigration)|(district attorney)|'\
                 '(factory inspector)|(^state)|(schools)|(public instruction)',wpos,flags=re.I) is not None: #school in wpos: superintendent of schools etc.
        wtype = 'official'
        wrep = 'government'
        
    #COMPANIES AND BUSINESS WPOS
    if re.search('(manufacturer)|(meat packer)|(dealer)|(business)|(capitalist)|(importer)|(industrialist)|(merchant)|(builder)|(contractor)|(mine operator)|(proprietor)',wpos,flags=re.I) is not None:
        wtype = 'company'        
        wrep = 'business'
    
   # COMPANIES AND BUSINES  WPOS if mistakenly in wpos
    if re.search('(company)|(works)|(and son)|(& son)|(coal exchange)|(steamship co)|(shipyard)|(fuel co)|(mills)|(bank)|(insurance)',wpos,flags=re.I) is not None:
        worg = wpos
        wpos = ''
        
    # DETECTIVE/POLICE and LAW ENFORCEMENT (this does not include judicial system etc., only police and detectives, public and private)
    if re.search('(national guard)',worg,flags=re.I) is not None or re.search('(national guard)',wpos,flags=re.I) is not None:
        wtype = 'law-public'
        wrep = 'enforcement'
    if re.search('(police)|(sheriff)|(US Marshal)',worg,flags=re.I) is not None or re.search('(police)|(sheriff)|(US Marshal)',wpos,flags=re.I) is not None:    
        if re.search('(coal)|(railway)|(railroad)',worg,flags=re.I) is not None:
            wtype = 'law-private'
        else:
            wtype = 'law-public'
        wrep = 'enforcement'           
    if re.search('(detective)',worg,flags=re.I) is not None or  re.search('(detective)|(investigator)',wpos,flags=re.I) is not None:
        wtype = 'law-private'
        wrep = 'enforcement'
    

       
        
        
    ####### WORG ########## 
    #this is pretty generic
    if  re.search('(association)|(society)',worg,flags=re.I) is not None:
        wtype = 'organization' #not public, of course, since a lot of these are empl. assns
        

    # WORKERS OR BUSINESS, DEPENDING
    if re.search('(railroad)|(railway)|(locomotive)',worg,flags=re.I) is not None:
        if re.search('(brotherhood)|(union)|(order)',worg,flags=re.I) is not None:        
            wtype = 'worker'
            wrep = 'labor'
        else:
            wtype = 'company'
            wrep = 'business'   
            
    # POLITICS
    if re.search('(campaign)|(republican)|(democratic)|(farmer-labor)|(greenback)|(socialist party)',worg,flags=re.I) is not None:
        wtype = 'politics'
    if re.search('(socialist)|(labor)',worg,flags=re.I):
        wrep = 'labor'
        

    #COMPANIES AND BUSINESS
    if  re.search('(company)|(companies)|(works)|(and son)|(& son)|(coal exchange)|'\
                  '(steamship co)|(shipyard)|(fuel co)|(mills)|(bank)|(insurance)',worg,flags=re.I) is not None:
        wtype = 'company'
        wrep = 'business'
    if re.search('corporation',worg,flags=re.I) is not None and re.search('army',worg,flags=re.I) is None:
        wtype = 'company'
        wrep = 'business' #because there are things like Army Corporation of Engineers
    if  re.search('(antiboycott)|(bottlers association)|(builders)|(building trades council)|(building trades)|'\
                '(business)|(cane growers)|(carriers association)|(cattle raisers)|'\
                '(citizens association)|(citizens association)|(coal operators)|'\
                '(commerce)|(dealer)|(employers)|(employing)|(erectors)|(founders)|'\
                '(harbor association)|(importer)|(industry)|(iron association)|'\
                '(lake carriers)|(lines)|(livestock)|(manufactu)|(merchant)|'\
                '(metal trades ass)|(packers association)|(paper and pulp)|(potters association)|'\
                '(producer)|(retail)|(shipping interests)|(shoe and leather association)|(steamship)|'\
                '(sugar planter)|(trade)|(typothetae)|(wholesale coal)|'\
                '(wholesale grocers)|(wholesale)',worg,flags=re.I) is not None:
        wrep = 'business'
        
        
            
    # PUBLIC
    if re.search("(adventists)|(american legion)|(archdiocese)|(bishop)|(catholic)|'\
                '(charities)|(child)|(chinese societ)|(christian)|(church)|(civic)|(college)|'\
                '(consumers league)|(daughters of)|(disabled)|(efficiency society)|(education)|(evangelical)|'\
                '(federation of women)|(german societ)|(greek)|(hebrew)|(hibernian)|(historical association)|(home economics)|'\
                '(hospital)|(humanit)|(hull house)|(institution)|(institute)|(invalid)|(italian americ)|(italian societ)|(irish freedom)|(irish societ)|(jewish)|(land reform)|(league)|(librar)|'\
                '(library)|(medical)|(mothers)|(marine society)|(national woman)|(of women)|'\
                '(order of moose)|(pastor)|(patriotic order)|(parent teacher)|(parents and teachers)|(pta)|(parent-teacher)|(peace)|(preparedness)|'\
                '(prohibition)|(protestant)|(public health)|(prison association)|(pure food)|'\
                '(race congress)|(red cross)|(relief)|(rotary)|(russell sage)|(sabbath)|(school)|'\
                '(scouts)|(settlement)|(society of friends)|(sons of)|(statistical association)|'\
                '(suffrage)|(synagogue)|(taft club)|(temperance)|'\
                '(tuberculosis)|(university)|(women's city)|(women's national)",worg,flags=re.I) is not None:
        wtype = 'organization'
        wrep = 'public'
    
    #PUBLIC - FARM
    if re.search('(agricultur)|(apple growers)|(cattle)|(cotton association)|'\
                '(cotton exchange)|(cotton growers)|(citrus growers)|(farm)|(fruit exchange)|'\
                '(fruit growers)|(goat)|(grange)|(growers association)|(hemp growers)|(horticultur)|'\
                '(raisers)|(rice growers)|(sheep)|(wine growers)|(wool growers)',worg,flags=re.I) is not None:   
        wtype = 'farm organization'
        wrep = 'public'


    #GOVERNMENT     
    if re.search('(alien property custodian)|(army)|(board of arbitr)|'\
                '(bureau)|(canal commission)|(court)|(ellis island)|(department)|(geographic board)'\
                '(house of representat)|(icc)|(indian affairs)|(land office)|'\
                '(legislature)|(national park)|(navy)|(office of)|(patent office)|(\Wport($|\W))'\
                '(postmaster general)|(reformatory)|(senate)|(service)|(shipping board)|(tariff commission)|'\
                '(state board)|(survey)|(united states department of agriculture)|(veterans board)|(war industries board)',worg,flags=re.I) is not None:        
        wrep = 'government'
        
    # WORKERS
    if re.search('(amalgamated)|(american federation of labor)|(brotherhood)|(bricklayers)|(central federated)|'\
                '(central labor)|(cigar makers)|(cigarmakers)|(cooks and pastry bakers)|'\
                '(employees)|(federation of teachers)|(federated union)|(granite cutters)|'\
                '(glass bottle blowers)|(hat makers)|(hatmakers)|(international union)|(journeymen)|(journeyman)|(knights of labor)|'\
                '(laborers)|(letter carriers)|(longshoremen)|(machinist)|(mine workers)|(miners)|'\
                '(mule spinners)|(plasterers)|(protective association)|(seamen)|(socialist)|(stereotypers)|(electrotypers)|(stone cutters)|(typographical)'\
                '(united american mechanics)|(weavers)|(workers)|(working men)|(working class)|(working-class)|'\
                '(working women)|(workingmen)',worg,flags=re.I) is not None:
        wtype = 'worker'
        wrep = 'labor'
    if re.search('employees of',wpos,flags=re.I) is not None or re.search('employees of',worg,flags=re.I) is not None:
        wtype = 'worker'        
        wrep = 'labor'
        
    # PRESS & MEDIA
    if  re.search('(herald)|(daily)|(weekly)|(semiweekly)|(times)|(journal)|'\
                  '(dispatch)|(magazine)|(newspaper)|(tribune)|(broadcast)|(editor)|(press)|(\WSun\W)',worg,flags=re.I) is not None:
        wtype = 'media'
        if re.search('(labor)|(socialist)|(work)',worg,flags=re.I) is not None:
            wrep = 'labor'
        else:
            wrep = 'public'      
    
    if re.search('inspector',wpos,flags=re.I) is not None and not worg:
        wrep = 'public'
    
    #[hid,hdate,hcongress,htitle,hcommittee,wlname,wfname,wpos,worg,city,state] + subjectlist
            
    newlist = [hid,hyear,hdate,hcongress,hsession,htitle,hcommittee,wlname,wfname,wpos,worg,city,state,wtype,wrep] + subjects
    newwitnesslist.append(newlist)

stringlist = []
for wlist in newwitnesslist:
    wstring = "\t".join(wlist)
    stringlist.append(wstring)
witnessestext = "\n".join(stringlist)

with open(workdir+writefile, 'w') as f:
    f.write(witnessestext)
            
            
            
