# -*- coding: utf-8 -*-
"""
Created on Wed Nov 25 10:18:40 2015

@author: vilja

Modified Oct 2018, but NOTE am not actually using this except used it a bit
for seeding the greps; mostly it's done like described in processwitness-newxml-id.py
"""

import re,os,codecs

workdir = "/Users/vilja/work/research/digital/"
#csvfile = "LexisNexis/test_processed.csv"
#csvfile =  workdir + "ProQuestHearings/witnesslist-newxml_secondpass10K.tsv"
csvfile = "/Users/vilja/work/research/digital/ProQuestHearings/orgssorted2.txt"
#statefile = "listsforprocessing/states.csv"
#placefile = "listsforprocessing/placenames-processed.csv"
orgsfile = workdir + "ProQuestHearings/organizations.tsv"
posfile = workdir + "ProQuestHearings/positions.tsv"
#writefile = workdir + "ProQuestHearings/witnesslist-newxml_id10K.tsv"
writefile = "/Users/vilja/work/research/digital/ProQuestHearings/orgssorted-id.txt"
if os.path.exists(writefile): os.remove(writefile) 


counter = 0
with codecs.open(csvfile,encoding='utf8') as f:
    for line in f:
#        counter += 1
#        print "Processing line {0} ...".format(counter)
        w = line.strip().split('\t')
        #print line
#        #reset every time and ensure they're at least defined
#        HID = w[0]
#        title = w[1]
#        date = w[2]
#        year = w[3]
#        congress = w[4]
#        session = w[5]
#        branch = w[6]
#        committee = w[7]
#        subcommittee = w[8]
#        lname = w[9]
#        fname = w[10]
#        hon = w[11]
#        suffix = w[12]
#        pos = w[13]
#        org = w[14]
#        city = w[15]
#        state = w[16]
#        addl = w[17]
#        subjects = w[18:]
        
        org = w[0]
        pos = ""
    # Then start trying to identify
    
        wtype = '' #define worker, company, politician, organization, farm organization, media (incl broadcasting), detective, police, politics, judiciary, executive, religious   --- organization incl. empl. but not union, which is in worker; organization also includes religious organizations and churches
        wrep = '' #define labor, business, public, government ---government includes politics and executive


       ####### org ########## 
        #this is pretty generic
        if  re.search('(association)|(society)',org,flags=re.I) is not None:
            wtype = 'organization' #not public, of course, since a lot of these are empl. assns
            
    
        # WORKERS OR BUSINESS, DEPENDING
        if re.search('(railroad)|(railway)|(locomotive)',org,flags=re.I) is not None:
            if re.search('(brotherhood)|(union)|(order)',org,flags=re.I) is not None:        
                wtype = 'worker'
                wrep = 'labor'
            else:
                wtype = 'company'
                wrep = 'business'   
                
        # POLITICS
        if re.search('(campaign)|(republican)|(democratic)|(farmer-labor)|(greenback)|(socialist party)',org,flags=re.I) is not None:
            wtype = 'politics'
        if re.search('(socialist)|(labor)',org,flags=re.I):
            wrep = 'labor'
            
    
        #COMPANIES AND BUSINESS
        if  re.search('(company)|(companies)|(works)|(and son)|(& son)|(coal exchange)|'\
                      '(steamship co)|(shipyard)|(fuel co)|(mills)|(bank)|(insurance)',org,flags=re.I) is not None:
            wtype = 'company'
            wrep = 'business'
        if re.search('corporation',org,flags=re.I) is not None and re.search('army',org,flags=re.I) is None:
            wtype = 'company'
            wrep = 'business' #because there are things like Army Corporation of Engineers
        if  re.search('(antiboycott)|(bottlers association)|(builders)|(building trades council)|(building trades)|'\
                    '(business)|(cane growers)|(carriers association)|(cattle raisers)|'\
                    '(citizens association)|(citizens association)|(coal operators)|'\
                    '(commerce)|(dealer)|(employers)|(employing)|(erectors)|(founders)|'\
                    '(harbor association)|(importer)|(industry)|(iron association)|'\
                    '(lake carriers)|(lines)|(livestock)|(manufactu)|(merchant)|'\
                    '(metal trades ass)|(packers association)|(paper and pulp)|(potters association)|'\
                    '(producer)|(retail)|(shipping interests)|(shoe and leather association)|(steamship)|'\
                    '(sugar planter)|(trade)|(typothetae)|(wholesale coal)|'\
                    '(wholesale grocers)|(wholesale)',org,flags=re.I) is not None:
            wrep = 'business'
            
            
                
        # PUBLIC
        if re.search("(adventists)|(american legion)|(archdiocese)|(bishop)|(catholic)|'\
                    '(charities)|(child)|(chinese societ)|(christian)|(church)|(civic)|(college)|'\
                    '(consumers league)|(daughters of)|(disabled)|(efficiency society)|(education)|(evangelical)|'\
                    '(federation of women)|(german societ)|(greek)|(hebrew)|(hibernian)|(historical association)|(home economics)|'\
                    '(hospital)|(humanit)|(hull house)|(institution)|(institute)|(invalid)|(italian americ)|(italian societ)|(irish freedom)|(irish societ)|(jewish)|(land reform)|(league)|(librar)|'\
                    '(library)|(medical)|(mothers)|(marine society)|(national woman)|(of women)|'\
                    '(order of moose)|(pastor)|(patriotic order)|(parent teacher)|(parents and teachers)|(pta)|(parent-teacher)|(peace)|(preparedness)|'\
                    '(prohibition)|(protestant)|(public health)|(prison association)|(pure food)|'\
                    '(race congress)|(red cross)|(relief)|(rotary)|(russell sage)|(sabbath)|(school)|'\
                    '(scouts)|(settlement)|(society of friends)|(sons of)|(statistical association)|'\
                    '(suffrage)|(synagogue)|(taft club)|(temperance)|'\
                    '(tuberculosis)|(university)|(women's city)|(women's national)",org,flags=re.I) is not None:
            wtype = 'organization'
            wrep = 'public'
        
        #PUBLIC - FARM
        if re.search('(agricultur)|(apple growers)|(cattle)|(cotton association)|'\
                    '(cotton exchange)|(cotton growers)|(citrus growers)|(farm)|(fruit exchange)|'\
                    '(fruit growers)|(goat)|(grange)|(growers association)|(hemp growers)|(horticultur)|'\
                    '(raisers)|(rice growers)|(sheep)|(wine growers)|(wool growers)',org,flags=re.I) is not None:   
            wtype = 'farm organization'
            wrep = 'public'
    
    
        #GOVERNMENT     
        if re.search('(alien property custodian)|(army)|(board of arbitr)|'\
                    '(bureau)|(canal commission)|(court)|(ellis island)|(department)|(geographic board)'\
                    '(house of representat)|(icc)|(indian affairs)|(land office)|'\
                    '(legislature)|(national park)|(navy)|(office of)|(patent office)|(\Wport($|\W))'\
                    '(postmaster general)|(reformatory)|(senate)|(service)|(shipping board)|(tariff commission)|'\
                    '(state board)|(survey)|(united states department of agriculture)|(veterans board)|(war industries board)',org,flags=re.I) is not None:        
            wrep = 'government'
            
        # WORKERS
        if re.search('(amalgamated)|(american federation of labor)|(brotherhood)|(bricklayers)|(central federated)|'\
                    '(central labor)|(cigar makers)|(cigarmakers)|(cooks and pastry bakers)|'\
                    '(employees)|(federation of teachers)|(federated union)|(granite cutters)|'\
                    '(glass bottle blowers)|(hat makers)|(hatmakers)|(international union)|(journeymen)|(journeyman)|(knights of labor)|'\
                    '(laborers)|(letter carriers)|(longshoremen)|(machinist)|(mine workers)|(miners)|'\
                    '(mule spinners)|(plasterers)|(protective association)|(seamen)|(socialist)|(stereotypers)|(electrotypers)|(stone cutters)|(typographical)'\
                    '(united american mechanics)|(weavers)|(workers)|(working men)|(working class)|(working-class)|'\
                    '(working women)|(workingmen)',org,flags=re.I) is not None:
            wtype = 'worker'
            wrep = 'labor'
            
        if re.search('employees of',pos,flags=re.I) is not None or re.search('employees of',org,flags=re.I) is not None:
            wtype = 'worker'        
            wrep = 'labor'
            
        # PRESS & MEDIA
        if  re.search('(herald)|(daily)|(weekly)|(semiweekly)|(times)|(journal)|'\
                      '(dispatch)|(magazine)|(newspaper)|(tribune)|(broadcast)|(editor)|(press)|(\WSun\W)',org,flags=re.I) is not None:
            wtype = 'media'
            if re.search('(labor)|(socialist)|(work)',org,flags=re.I) is not None:
                wrep = 'labor'
            else:
                wrep = 'public'      
        
        if re.search('inspector',pos,flags=re.I) is not None and not org:
            wrep = 'public'
    
    #XXXXX positions XXXX
        
        # PRESS pos
        if  re.search('(editor)|(publisher)|(correspondent)|(newspaperman)|(newspaper man)|(journalist)',pos,flags=re.I) is not None:
            wtype = 'media'
            if re.search('(labor)|(socialist)|(work)',org,flags=re.I) is not None:
                wrep = 'labor'
            else:
                wrep = 'public'    
                
        #POLITICS pos
    #    if re.search('(representative)|(senator)',pos,flags=re.I) is not None:
    #        wtype = 'politics'        
    #        wrep = 'government'
        if re.search('party',org,flags=re.I) is not None:
            wtype = 'politics'
            wrep = 'government'
            
        # PUBLIC pos
        if re.search('(pastor)|(bishop)|(reverend)|(chaplain)|(missionary)',pos,flags=re.I) is not None:
            wtype = 'religious'
            wrep = 'public'
            
        if re.search('(professor)|(historian)|(principal)|(lecturer)|(economist)|(statistician)',pos,flags=re.I) is not None:
            wrep = 'public'
        
        # PUBLIC #if these mistakenly in pos
    #    if re.search('(adventists)|(american legion)|(archdiocese)|(bishop)|(catholic)|'\
    #                '(charities)|(child)|(christian)|(church)|(civic)|(college)|'\
    #                '(consumers league)|(disabled)|(education)|(evangelical)|'\
    #                '(federation of women)|(hebrew)|(hibernian)|(hull house)|(home economics)|'\
    #                '(hospital)|(institution)|(invalid)|(jewish)|(league)|'\
    #                '(library)|(marine society)|(national woman)|(of women)|'\
    #                '(order of moose)|(patriotic order)|(preparedness)|'\
    #                '(prohibition)|(protestant)|(public health)|(pure food)|'\
    #                '(race congress)|(relief)|(rotary)|(russell sage)|'\
    #                '(scouts)|(society of friends)|(statistical association)|'\
    #                '(suffrage)|(synagogue)|(taft club)|(temperance)|'\
    #                '(tuberculosis)|(university)',org,flags=re.I) is not None:
    #        org = pos
    #        pos = ''
        
        # PRINTER: ^(public)\s*printer
        # WORKER pos
        if re.search('(blacksmith)|(cigar maker)|(cigarmaker)|(cooper)|(repairer)|(telegrapher)|(carpenter)|(slaughterer)|(butcher)|(tinner)|(dressmaker)|(coal man)|(conductor)|(cutter)|(cloak maker)|(employee)|(grocer)|(labor)|'\
                    '(laborer)|(machinist)|(\Wmechanic\W)|(miner)|'\
                    '(molder)|(motorman)|(plumber)|(printer)|(striker)|(tailor)|(telegrapher)'\
                    '(type founder)|(worker)',pos,flags=re.I) is not None:
            wtype = 'worker'
            wrep = 'labor'
    
        #PUBLIC - FARM pos
        if re.search('(farmer)|(grower)|(raiser)',pos,flags=re.I) is not None:   
            wtype = 'agriculture'
            wrep = 'public'
    
            
        # GOVERNMENT pos
        if re.search('(judge)|(attorney general)|(district attorney)|(justice)',pos,flags=re.I) is not None:
            wtype = 'judiciary'
            wrep = 'government'
        if re.search('(adjutant general)|(adjutant-general)|(postmaster)|(postmistress)|(superintendent of mails)|(governor)|(mayor)|'\
                     '(attorney general)|(commissioner of immigration)|(district attorney)|'\
                     '(factory inspector)|(^state)|(schools)|(public instruction)',pos,flags=re.I) is not None: #school in pos: superintendent of schools etc.
            wtype = 'official'
            wrep = 'government'
            
        #COMPANIES AND BUSINESS pos
        if re.search('(manufacturer)|(meat packer)|(dealer)|(business)|(capitalist)|(importer)|(industrialist)|(merchant)|(builder)|(contractor)|(mine operator)|(proprietor)',pos,flags=re.I) is not None:
            wtype = 'company'        
            wrep = 'business'
        
    #   # COMPANIES AND BUSINES  pos if mistakenly in pos
    #    if re.search('(company)|(works)|(and son)|(& son)|(coal exchange)|(steamship co)|(shipyard)|(fuel co)|(mills)|(bank)|(insurance)',pos,flags=re.I) is not None:
    #        org = pos
    #        pos = ''
            
        # DETECTIVE/POLICE and LAW ENFORCEMENT (this does not include judicial system etc., only police and detectives, public and private)
        if re.search('(national guard)',org,flags=re.I) is not None or re.search('(national guard)',pos,flags=re.I) is not None:
            wtype = 'law-public'
            wrep = 'enforcement'
        if re.search('(police)|(sheriff)|(US Marshal)',org,flags=re.I) is not None or re.search('(police)|(sheriff)|(US Marshal)',pos,flags=re.I) is not None:    
            if re.search('(coal)|(railway)|(railroad)',org,flags=re.I) is not None:
                wtype = 'law-private'
            else:
                wtype = 'law-public'
            wrep = 'enforcement'           
        if re.search('(detective)',org,flags=re.I) is not None or  re.search('(detective)|(investigator)',pos,flags=re.I) is not None:
            wtype = 'law-private'
            wrep = 'enforcement'
        
    
        #and then, finally, put everything in a list
    #    newwline = [HID, title, date, year, congress, session, branch, committee, subcommittee, lname, fname, hon, suffix, pos, org, city, state, addl] + subjects
        newwline = [w[0],w[1],wtype,wrep]
        newwlinetxt = '\t'.join(newwline) + '\n'
        print newwlinetxt
        with codecs.open(writefile,'a',encoding='utf8') as f1:
            f1.write(newwlinetxt)    
            
                
